package cc.ibadboy.hibernate.hibernate2.test;

import cc.ibadboy.hibernate.hibernate2.entity.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Test;

public class HibernateTest {

    @Test
    public void hibernateTest1(){

        //第一步 装载hibernate.cfg.xml
        //Configuration() 可是使用有参数构造，可以填写你指定的hibernate的文件名，例如hiber.cfg.xml
        //如果不填写则默认装载src根目录下的hibernate.cfg.xml
        //Configuration configuration = new Configuration();

        //第二步
        //Hibernate 5.x版本创建SessionFactory方法
        //StandardServiceRegistry接口是一个标准服务注册接口，扩展ServiceRegistry
        //使用StandardServiceRegistryBuilder()生成标准ServiceRegistry实例。
        //configure() 此方法是来加载hibernate.cfg.xml文件，也就是说使用Hibernate5.x，我们可以省略第一步
        //build() 此方法是用来构建StandardServiceRegistry
        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
        //我们在上面只是创建了一个标准的服务，但是Hibernate并不知道我们的映射有那些所以需要创建Metadata对象
        //Metadata对象表示从映射来源确定orm模型，然后在通过buildSessionFactory()方法来创建SessionFactory对象
        SessionFactory sessionFactory = new MetadataSources(serviceRegistry).buildMetadata().buildSessionFactory();

        //第三步
        Session session = sessionFactory.openSession();

        //第四步
        Transaction transaction = session.beginTransaction();

        //第五步
        //我们先创建一个User对象
        User user = new User();
        user.setId(1);
        user.setName("张三");
        user.setPwd("123");
        //然后执行Hibernate的保存操作
        session.save(user);
        //第六步
        transaction.commit();
        //提交事务，做数据持久化操作

        //第七步
        session.close();

    }


}
